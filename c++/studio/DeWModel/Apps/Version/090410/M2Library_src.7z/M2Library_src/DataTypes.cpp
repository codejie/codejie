#include "stdafx.h"

#include "DataTypes.h"


namespace M2
{

int Header_t::Read(CFileBuffer& fb)
{
	fb.Read(m_acIdent, 4);
	fb.Read(m_uiVersion);
	m_stName.Read(fb);
	fb.Read(m_uiModelFlag);
	m_stSequence.Read(fb);
	m_stAnim.Read(fb);
	m_stAnimLookup.Read(fb);
	m_stBone.Read(fb);
	m_stBoneLookup.Read(fb);
	m_stVertex.Read(fb);
	fb.Read(m_uiView);
	m_stColor.Read(fb);
	m_stTexture.Read(fb);
	m_stTransparency.Read(fb);
	m_stTexAnim.Read(fb);
	m_stTexReplace.Read(fb);
	m_stRenderFlag.Read(fb);
	m_stBoneTable.Read(fb);
	m_stTexLookup.Read(fb);
	m_stTexTable.Read(fb);
	m_stTransLookup.Read(fb);
	m_stTexAnimLookup.Read(fb);
	fb.Read(m_acUnknFloat, 14 * sizeof(float));
	m_stBoundTriangle.Read(fb);
	m_stBoundVertex.Read(fb);
	m_stBoundNormal.Read(fb);
	m_stAttachment.Read(fb);
	m_stAttachLookup.Read(fb);
	m_stAttachment2.Read(fb);
	m_stLight.Read(fb);
	m_stCamera.Read(fb);
	m_stCameraLookup.Read(fb);
	m_stRibbon.Read(fb);
	m_stParticle.Read(fb);

	return fb.Good() ? 0 : -1;
}


int Animation_t::Read(CFileBuffer& fb)
{
	fb.Read(m_usID);
	fb.Read(m_usSubID);
	fb.Read(m_uiLength);
	fb.Read(m_fMovingSpeed);
	fb.Read(m_uiLoopType);
	fb.Read(m_uiFlag);
	fb.Read(m_uiUnkn);
	fb.Read(m_uiUnkn2);
	fb.Read(m_uiPlaySpeed);
	fb.Read(m_v3Box);
	fb.Read(m_v3Box2);
	fb.Read(m_fRadius);
	fb.Read(m_usNextID);
	fb.Read(m_usIndex);

	return fb.Good() ? 0 : -1;
}

int AnimBlock_t::Read(CFileBuffer& fb)
{
	fb.Read(m_usType);
	fb.Read(m_usSeq);
	m_stTimestamp.Read(fb);
	m_stKey.Read(fb);

	return fb.Good() ? 0 : -1;
}

int Bone_t::Read(CFileBuffer& fb)
{
	fb.Read(m_iAnimID);
	fb.Read(m_uiFlag);
	fb.Read(m_sParent);
	fb.Read(m_usGeoID);
	fb.Read(m_iUnkn);
	m_stTranslation.Read(fb);
	m_stRotation.Read(fb);
	m_stScaling.Read(fb);
	fb.Read(m_v3Pivot);

	return fb.Good() ? 0 : -1;
}

int Vertex_t::Read(CFileBuffer& fb)
{
	fb.Read(m_v3Pos);
	fb.Read(m_acWeight, 4);
	fb.Read(m_acBone, 4);
	fb.Read(m_v3Normal);
	fb.Read(m_v2TextureCoord);
	fb.Read(m_iUnkn);
	fb.Read(m_iUnkn2);

	return fb.Good() ? 0 : -1;
}

int Color_t::Read(CFileBuffer& fb)
{
	m_stColor.Read(fb);
	m_stOpacity.Read(fb);

	return fb.Good() ? 0 : -1;
}

int Texture_t::Read(CFileBuffer& fb)
{
	fb.Read(m_uiType);
	fb.Read(m_uiFlag);
	m_stName.Read(fb);
	//if(m_uiType == 0)
	//{
	//	fb.Seek(m_stName.offset);
	//	fb.Read(m_strName);
	//}

	return fb.Good() ? 0 : -1;
}

int TexFileName_t::Read(CFileBuffer &fb)
{
	return fb.Read(m_strName);
}

int Transparency_t::Read(CFileBuffer& fb)
{
	m_stTrans.Read(fb);

	return fb.Good() ? 0 : -1;
}

int TexAnim_t::Read(CFileBuffer& fb)
{
	m_stTranslation.Read(fb);
	m_stRotation.Read(fb);
	m_stScaling.Read(fb);

	return fb.Good() ? 0 : -1;
}

int RenderFlag_t::Read(CFileBuffer& fb)
{
	fb.Read(m_usFlag);
	fb.Read(m_usMode);

	return fb.Good() ? 0 : -1;
}

int BoundTriangle_t::Read(CFileBuffer& fb)
{
	fb.Read(m_usA);
	fb.Read(m_usB);
	fb.Read(m_usC);

	return fb.Good() ? 0 : -1;
}

int Attachment_t::Read(CFileBuffer& fb)
{
	fb.Read(m_uiID);
	fb.Read(m_iBoneID);
	fb.Read(m_v3Pos);
	m_stData.Read(fb);

	return fb.Good() ? 0 : -1;
}

int Attachment2_t::Read(CFileBuffer& fb)
{
	fb.Read(m_acID, 4);
	fb.Read(m_uiID);
	fb.Read(m_iBoneID);
	fb.Read(m_v3Pos);
	fb.Read(m_usType);
	fb.Read(m_usSeq);
	m_stRange.Read(fb);
	m_stTime.Read(fb);

	return fb.Good() ? 0 : -1;
}

int Light_t::Read(CFileBuffer& fb)
{
	fb.Read(m_usType);
	fb.Read(m_iBoneID);
	fb.Read(m_v3Pos);
	m_stAmbColor.Read(fb);
	m_stAmbIntensity.Read(fb);
	m_stColor.Read(fb);
	m_stIntensity.Read(fb);
	m_stAttStart.Read(fb);
	m_stAttEnd.Read(fb);
	m_stUnkn.Read(fb);

	return fb.Good() ? 0 : -1;
}

int Camera_t::Read(CFileBuffer& fb)
{
	fb.Read(m_iID);
	fb.Read(m_fFov);
	fb.Read(m_fFarClip);
	fb.Read(m_fNearClip);
	m_stTransPos.Read(fb);
	fb.Read(m_v3Pos);
	m_stTransTarget.Read(fb);
	fb.Read(m_v3TargetPos);
	m_stRot.Read(fb);

	return fb.Good() ? 0 : -1;
}

int Ribbon_t::Read(CFileBuffer& fb)
{
	fb.Read(m_iID);
	fb.Read(m_iBoneID);
	fb.Read(m_v3Pos);
	m_stTexture.Read(fb);
	m_stBlendRef.Read(fb);
	m_stColor.Read(fb);
	m_stOpacity.Read(fb);
	m_stAbove.Read(fb);
	m_stBlow.Read(fb);
	fb.Read(m_fResoluation);
	fb.Read(m_fLength);
	fb.Read(m_fAngle);
	fb.Read(m_sRender);
	fb.Read(m_sRender2);
	m_stUnkn.Read(fb);
	m_stUnkn2.Read(fb);
	fb.Read(m_iUnkn);

	return fb.Good() ? 0 : -1;
}

int FakeAnimBlock_t::Read(CFileBuffer& fb)
{
	m_stTimestamp.Read(fb);
	m_stKey.Read(fb);

	return fb.Good() ? 0 : -1;
}

int Particle_t::Read(CFileBuffer& fb)
{
	fb.Read(m_iID);
	fb.Read(m_uiFlag);
	fb.Read(m_v3Pos);
	fb.Read(m_sBoneID);
	fb.Read(m_sTexture);
	m_stName.Read(fb);
	m_stUnkn.Read(fb);
	fb.Read(m_sBlend);
	fb.Read(m_sEmitter);
	fb.Read(m_sParticle);
	fb.Read(m_sTexRot);
	fb.Read(m_sTexCol);
	fb.Read(m_sTexRow);
	m_stSpeed.Read(fb);
	m_sSpeedVar.Read(fb);
	m_stVerticalRange.Read(fb);
	m_stHorizontalRange.Read(fb);
	m_stGravity.Read(fb);
	m_stLifeSpan.Read(fb);
	fb.Read(m_iUnkn);
	m_stRate.Read(fb);
	fb.Read(m_iUnkn2);
	m_stAreaLength.Read(fb);
	m_stAreaWidth.Read(fb);
	m_stGravity2.Read(fb);
	m_stColor.Read(fb);
	m_stTimestamp.Read(fb);
	m_stSize.Read(fb);
	fb.Read((char*)m_aiUnkn, sizeof(int) *10);
	fb.Read((char*)m_afUnkn, sizeof(float) * 3);
	fb.Read(m_v3Scale);
	fb.Read(m_fSlowDown);
	fb.Read((char*)m_afUnkn2, sizeof(float) * 2);
	fb.Read(m_fRot);
	fb.Read((char*)m_afUnkn3, sizeof(float) * 2);
	fb.Read(m_v3Rot);
	fb.Read(m_v3Rot2);
	fb.Read(m_v3Trans);
	fb.Read((char*)m_afUnkn4, sizeof(float) * 6);
	m_stEnabled.Read(fb);

	return fb.Good() ? 0 : -1;
}

}//M2

namespace Skin
{

int Header_t::Read(CFileBuffer& fb)
{
	fb.Read(m_acIdent, 4);
	m_stIndex.Read(fb);
	m_stTriangle.Read(fb);
	m_stProperty.Read(fb);
	m_stSubMesh.Read(fb);
	m_stTexture.Read(fb);
	fb.Read(m_uiLOD);

	return fb.Good() ? 0 : -1;
}

int SubMesh_t::Read(CFileBuffer& fb)
{
	fb.Read(m_uiID);
	fb.Read(m_usVertexStart);
	fb.Read(m_usVertexCount);
	fb.Read(m_usTriangleStart);
	fb.Read(m_usTriangleCount);
	fb.Read(m_usBoneCount);
	fb.Read(m_usBoneStart);
	fb.Read(m_usUnkn);
	fb.Read(m_usBoneRoot);
	fb.Read(m_v3Pos);
	fb.Read((char*)m_afUnkn, sizeof(float) * 4);

	return fb.Good() ? 0 : -1;
}

int Texture_t::Read(CFileBuffer& fb)
{
	fb.Read(m_usFlag);
	fb.Read(m_usRenderOrder);
	fb.Read(m_usSubMeshIndex);
	fb.Read(m_usSubMeshIndex2);
	fb.Read(m_sColorIndex);
	fb.Read(m_usRenderFlag);
	fb.Read(m_usTexIndex);
	fb.Read(m_usUnkn);
	fb.Read(m_usTexture);
	fb.Read(m_usTexIndex2);
	fb.Read(m_usTransIndex);
	fb.Read(m_usTexAnimIndex);

	return fb.Good() ? 0 : -1;
}

}//skin
