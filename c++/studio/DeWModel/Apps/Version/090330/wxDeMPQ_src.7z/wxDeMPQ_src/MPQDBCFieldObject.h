#ifndef __MPQDBCFIELDOBJECT_H__
#define __MPQDBCFIELDOBJECT_H__

#include <string>
#include <map>

namespace DBCField
{
	class CField;
}

class CMPQDBCFieldManager
{
public:
	typedef std::map<int, DBCField::CField*> TFieldMap;
	typedef std::map<std::string, TFieldMap> TDBCMap;
	struct FieldAttr_t
	{
		std::string m_strTitle;
		int m_iPos;
		std::string m_strType;
		int m_iSize;
		std::string m_strRefDBC;
		int m_iRefPos;
		int m_iNumber;
	};
public:
	CMPQDBCFieldManager();
	virtual ~CMPQDBCFieldManager();

	int Load(const std::string& xml, bool reload = false);
	const TFieldMap* FindDBCFields(const std::string& dbc) const;
private:
	int ParseXML(const std::string& xml);
	DBCField::CField* MakeDBCField(const FieldAttr_t& attr) const;
	void Destory();
private:
	TDBCMap _mapDBC;
};
                               

namespace DBCField
{
enum FieldType { FT_INTEGER, FT_BOOLEAN, FT_STRING, FT_REFID, FT_ARRAYOFINTEGER };

class CField
{
public:
	CField(FieldType type, const std::string& title, int pos, int size)
		: m_strTitle(title), m_iPos(pos), m_eType(type), m_iSize(size)
	{
	}
	virtual ~CField() {}

public:
	FieldType m_eType;
	std::string m_strTitle;
	int m_iPos;
	int m_iSize;
};

class CIntegerField : public CField
{
public:
	CIntegerField(const std::string& title, int pos, int size)
		: CField(FT_INTEGER, title, pos, size)
	{
	}
};

class CStringField : public CField
{
public:
	CStringField(const std::string& title, int pos, int size)
		: CField(FT_STRING, title, pos, size)
	{
	}
};

}
#endif