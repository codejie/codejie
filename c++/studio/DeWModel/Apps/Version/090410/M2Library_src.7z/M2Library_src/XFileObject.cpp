#include "stdafx.h"

#include "M2Structure.h"
#include "SkinStructure.h"

#include "XFileObject.h"

using namespace X;

CXFileObject::CXFileObject()
{
}

CXFileObject::~CXFileObject()
{
}

int CXFileObject::Output(const CM2FileObject &m2, const CSkinFileObject &skin, const std::string &file)
{
	if(InitVertex(m2) != 0)
		return -1;
	if(InitTriangle(skin) != 0)
		return -1;
	if(InitTexture(m2) != 0)
		return -1;
	if(InitMesh(skin) != 0)
		return -1;

	std::ofstream ofs;
	if(CreateXFile(file, ofs) == 0)
	{
		OutputMaterial(ofs);
		OutputFrame(ofs);

		CloseXFile(ofs);
	}

	return 0;
}

int CXFileObject::InitVertex(const CM2FileObject &m2)
{
	for(M2::TVertex::TVector::const_iterator it = m2._vertex.m_vct.begin(); it != m2._vertex.m_vct.end(); ++ it)
	{
		Vertex_t vec;
		vec.m_v3Pos = it->m_v3Pos;
		vec.m_v3Normal = it->m_v3Normal;
		vec.m_v2TexCoord = it->m_v2TextureCoord;
		_vctVertex.push_back(vec);
	}

	return 0;
}

int CXFileObject::InitTriangle(const CSkinFileObject &skin)
{
	for(Skin::TTriangle::TVector::const_iterator it = skin._triangle.m_vct.begin(); it != skin._triangle.m_vct.end();)
	{
		Triangle_t tri;
		tri.m_usA = it->data;
		++ it;
		tri.m_usB = it->data;
		++ it;
		tri.m_usC = it->data;
		++ it;
		_vctTriangle.push_back(tri);
	}
	return 0;
}

int CXFileObject::InitTexture(const CM2FileObject &m2)
{
	return 0;
}

int CXFileObject::InitMesh(const CSkinFileObject &skin)
{
	unsigned short index = 0;
	Skin::TSubMesh::TVector::const_iterator it = skin._submesh.m_vct.begin();
	while(it != skin._submesh.m_vct.end())
	{
		TMeshMap::iterator i = _mapMesh.find(it->m_uiID);
		if(i == _mapMesh.end())
		{
			i = _mapMesh.insert(std::make_pair(it->m_uiID, TMeshIndexVector())).first;
		}
		MeshIndex_t mesh;
		mesh.m_usIndex = (index ++);
		mesh.m_usVecStart = it->m_usVertexStart;
		mesh.m_usVecCount = it->m_usVertexCount;
		mesh.m_usTriStart = it->m_usTriangleStart / 3;
		mesh.m_usTriCount = it->m_usTriangleCount / 3;

		i->second.push_back(mesh);

		++ it;
	}

	return 0;
}

///
int CXFileObject::CreateXFile(const std::string& file, std::ofstream& ofs) const
{
	ofs.open(file.c_str(), std::ios::out | std::ios::trunc);
	if(!ofs.is_open())
		return -1;

	//Init flag
	ofs.precision(6);
	//Header
	ofs << STR_X_HEADER << std::endl;

	return ofs.good() ? 0 : -1;
}


void CXFileObject::CloseXFile(std::ofstream &ofs) const
{
	if(ofs.is_open())
		ofs.close();
}

int CXFileObject::OutputMaterial(std::ofstream& ofs) const
{
	return 0;
}

int CXFileObject::OutputFrame(std::ofstream &ofs) const
{
	//Frame
	ofs << std::endl << "Frame M2 {" << std::endl;
	ofs << STR_TAB2 << "FrameTransformMatrix {" << std::endl;
	ofs << STR_TAB4 << "1.000000,0.000000,0.000000,0.000000," << std::endl;
	ofs << STR_TAB4 << "0.000000,1.000000,0.000000,0.000000," << std::endl;
	ofs << STR_TAB4 << "0.000000,0.000000,1.000000,0.000000," << std::endl;
	ofs << STR_TAB4 << "0.000000,0.000000,0.000000,1.000000;;" << std::endl;
	ofs << STR_TAB2 << "} " << std::endl;

	//Mesh
	OutputMesh(ofs);

	//Frame close
	ofs << "}" << std::endl;

	return ofs.good() ? 0 : -1;
}

int CXFileObject::OutputMesh(std::ofstream &ofs) const
{
	ofs << STR_TAB2 << "Mesh Mesh_for_de {" << std::endl;
	ofs << STR_TAB4 << "1;" << std::endl;
	ofs << STR_TAB4 << "0;0;0;;" << std::endl;
	ofs << STR_TAB4 << "0;" << std::endl;
	ofs << STR_TAB2 << "}" << std::endl;

	for(TMeshMap::const_iterator it = _mapMesh.begin(); it != _mapMesh.end(); ++ it)
	{
		//Mesh
		ofs << STR_TAB2 << "Mesh Mesh" << it->first << " {" << std::endl;
		//Number
		unsigned short vnum = 0, tnum = 0;
		for(TMeshIndexVector::const_iterator i = it->second.begin(); i != it->second.end(); ++ i)
		{
			vnum += i->m_usVecCount;
			tnum += i->m_usTriCount;
		}
		//Vertex
		ofs << STR_TAB4 << vnum << ";" << std::endl;
		for(TMeshIndexVector::const_iterator i = it->second.begin(); i != it->second.end(); ++ i)
		{
			for(unsigned short index = 0; index < i->m_usVecCount;)
			{
				ofs << STR_TAB4;
				OutputVertex(ofs, _vctVertex[index + i->m_usVecStart]);
				if((++ index) != i->m_usVecCount)
					ofs << "," << std::endl;
				else
					ofs << ";" << std::endl;
			}
		}
		//Triangle
		ofs << STR_TAB4 << tnum << ";" << std::endl;
		tnum = 0;
		for(TMeshIndexVector::const_iterator i = it->second.begin(); i != it->second.end(); ++ i)
		{
			for(unsigned short index = 0; index < i->m_usTriCount;)
			{
				ofs << STR_TAB4;
				OutputTriangle(ofs, _vctTriangle[index + i->m_usTriStart], i->m_usVecStart - tnum);
				if((++ index) != i->m_usTriCount)
					ofs << "," << std::endl;
				else
					ofs << ";" << std::endl;
			}
			tnum += i->m_usVecCount;
		}
	
		ofs << STR_TAB2 << "}" << std::endl;//Mesh
	}
	
	return 0;
}

////////
void CXFileObject::OutputVertex(std::ostream &os, const Vertex_t &vec) const
{
	os << vec.m_v3Pos.x << ";" << vec.m_v3Pos.y << ";" << vec.m_v3Pos.z << ";";
}

void CXFileObject::OutputTriangle(std::ostream &os, const Triangle_t &tri, unsigned short base) const
{
	os << "3;" << tri.m_usA - base << "," << tri.m_usB - base << "," << tri.m_usC - base << ";";
}


