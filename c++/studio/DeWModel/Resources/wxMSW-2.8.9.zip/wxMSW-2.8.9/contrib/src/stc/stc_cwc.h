#define __WX__
#define SCI_LEXER
#define LINK_LEXERS
#include "wx/wx_cwc.h"