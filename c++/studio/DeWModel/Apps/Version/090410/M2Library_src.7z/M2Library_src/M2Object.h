#ifndef __M2OBJECT_H__
#define __M2OBJECT_H__

#ifdef M2LIBRARY_EXPORTS
#define M2LIBRARY_API __declspec(dllexport)
#else
#define M2LIBRARY_API __declspec(dllimport)
#endif

#include <string>

#include "M2FileObject.h"
#include "SkinFileObject.h"

class M2LIBRARY_API CM2Object
{
public:
	CM2Object();
	virtual ~CM2Object();

	int Load(const std::string& file);

	int ToXFile(const std::string& file) const;
protected:
	int LoadM2File(const std::string& file);
	int LoadSkinFile(const std::string& file);
protected:
	CM2FileObject _objM2;
	CSkinFileObject _objSkin;
};


#endif
