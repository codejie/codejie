#include "stdafx.h"

#include "Toolkit.h"

#include "XFileObject.h"
#include "BLPFileObject.h"
#include "ModelObject.h"

CModelObject::CModelObject()
{
}

CModelObject::~CModelObject()
{
}

int CModelObject::Init(const std::wstring& path, bool findmpq)
{
	_vctMPQ.clear();
	_bFindMPQ = findmpq;

	return ScanMPQPath(path);
}

int CModelObject::LoadModel(const std::wstring &mpq, const std::wstring &m2)
{
	_strMPQ = mpq;
	_strM2 = m2;


	std::wstring skinfile = _strM2;
	std::wstring::size_type pos = skinfile.find_last_of(L".");
	if(pos == std::wstring::npos)
		return -1;
	skinfile = skinfile.substr(0, pos);
//	std::wstring blpfile = skinfile + ".blp";
	skinfile += L"00.skin";

	if(LoadM2Object(_strMPQ, _strM2) != 0)
		return -1;
	if(LoadSkinObject(_strMPQ, skinfile) != 0)
		return -1;
	
	//if(ExtractBLPFile(mpq, blpfile) != 0)
	//	return -1;
	return 0;
}

int CModelObject::ToXFile(const std::wstring &file)
{
	std::wstring path = file;
	std::wstring::size_type pos = path.find_last_of(L"\\");
	if(pos != std::wstring::npos)
	{
		path = path.substr(0, pos + 1);
	}
	else
	{
		path = L"";
	}

	CXFileObject x;
	if(x.Output(_objM2, _objSkin, file) == 0)
	{
		for(M2::TTexFileName::TVector::const_iterator it = _objM2._texfilename.m_vct.begin(); it != _objM2._texfilename.m_vct.end(); ++ it)
		{
			std::wstring m2(it->begin(), it->end());// = *it;
			std::wstring png = m2;
			std::wstring::size_type pos = png.find_last_of(L"\\");
			if(pos != std::wstring::npos)
				png = png.substr(pos + 1);
			png += L".png";
			png = path + png;
			if(ExtractBLPFile(_strMPQ, m2, png) != 0)
			{
			}
		}

		return 0;
	}
	return -1;
}

int CModelObject::LoadM2Object(const std::wstring& mpq, const std::wstring& file)
{
	std::string m = Toolkit::WString2String(mpq);
	std::string f = Toolkit::WString2String(file);
	return _objM2.Load(m, f);
}

int CModelObject::LoadSkinObject(const std::wstring& mpq, const std::wstring& file)
{
	std::string m = Toolkit::WString2String(mpq);
	std::string f = Toolkit::WString2String(file);
	return _objSkin.Load(m, f);
}

int CModelObject::ExtractBLPFile(const std::wstring& mpq, const std::wstring& blp, const std::wstring& png)
{
	std::string m = Toolkit::WString2String(mpq);
	std::string b = Toolkit::WString2String(blp);
	std::string p = Toolkit::WString2String(png);
	CBLPFileObject obj;
	
	int ret = obj.Extract2PNG(m, b, p);
	if(ret != 0 && _bFindMPQ)
	{
		for(TMPQVector::iterator it	= _vctMPQ.begin(); it != _vctMPQ.end(); ++ it)
		{
			m = Toolkit::WString2String(*it);
			ret = obj.Extract2PNG(m, b, p);
			if(ret == 0)
			{
				if(it != _vctMPQ.begin())
					std::swap(_vctMPQ.begin(), it);
				break;
			}
		}
	}

	return ret;
//	return obj.Extract2PNG(m, b, p);
}

int CModelObject::ScanMPQPath(const std::wstring &path)
{
	std::wstring str = path + L"\\*";
	WIN32_FIND_DATA fdata;
	memset(&fdata, 0, sizeof(WIN32_FIND_DATA));
	HANDLE h = ::FindFirstFile(str.c_str(), &fdata);
	if(h == INVALID_HANDLE_VALUE)
		return -1;
	do
	{
		if((fdata.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY)
		{
			if((memcmp(fdata.cFileName, ".", 1) != 0) && (memcmp(fdata.cFileName, "..", 2)))
				ScanMPQPath(path + L"\\" + fdata.cFileName);
		}
		else if((fdata.dwFileAttributes & FILE_ATTRIBUTE_ARCHIVE) == FILE_ATTRIBUTE_ARCHIVE)
		{
			str = fdata.cFileName;
			//std::wstring::size_type pos = str.find(L".MPQ"); 
			if(str.find(L".MPQ") != std::wstring::npos)
				_vctMPQ.push_back(path + L"\\" + str);
		}
	}while(FindNextFile(h, &fdata) == TRUE);
	::FindClose(h);
	return 0;
}
