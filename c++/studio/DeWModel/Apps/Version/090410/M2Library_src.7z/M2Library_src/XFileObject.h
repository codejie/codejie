#ifndef __XFILEOBJECT_H__
#define __XFILEOBJECT_H__

#include <string>
#include <vector>
#include <map>
//#include <ostream>
#include <fstream>

#include "vec3d.h"

#include "M2FileObject.h"
#include "SkinFileObject.h"

namespace X
{

const std::string STR_X_HEADER		= "xof 0303txt 0032";
const std::string STR_TAB2			= "  ";
const std::string STR_TAB4			= "    ";
const std::string STR_TAB6			= "      ";
const std::string STR_TAB8			= "        ";

struct Vertex_t
{
	vec3d m_v3Pos;
	vec3d m_v3Normal;
	vec2d m_v2TexCoord;
};

typedef std::vector<Vertex_t> TVertexVector;

struct Triangle_t
{
	unsigned short m_usA;
	unsigned short m_usB;
	unsigned short m_usC;
};

typedef std::vector<Triangle_t> TTriangleVector;

struct Texture_t
{
	std::string m_strFileNmae;
};

typedef std::map<unsigned short, Texture_t> TTextureMap;//Mesh Index + Texture;


struct MeshIndex_t
{
	unsigned short m_usIndex;
	unsigned short m_usVecStart;
	unsigned short m_usVecCount;
	unsigned short m_usTriStart;
	unsigned short m_usTriCount;
};

typedef std::vector<MeshIndex_t> TMeshIndexVector;
typedef std::map<unsigned int, TMeshIndexVector> TMeshMap;//ID + Triangle


}


class CXFileObject
{
public:
	CXFileObject();
	virtual ~CXFileObject();

	int Output(const CM2FileObject& m2, const CSkinFileObject& skin, const std::string& file);
private:
	int InitVertex(const CM2FileObject& m2);
	int InitTriangle(const CSkinFileObject& skin);
	int InitTexture(const CM2FileObject& m2);
	int InitMesh(const CSkinFileObject& skin);
private:
	int CreateXFile(const std::string& file, std::ofstream& ofs) const;
	void CloseXFile(std::ofstream& ofs) const;
	int OutputMaterial(std::ofstream& ofs) const;
	int OutputFrame(std::ofstream& ofs) const;
	int OutputMesh(std::ofstream&ofs) const;
private:
	void OutputVertex(std::ostream& os, const X::Vertex_t& vec) const;
	void OutputTriangle(std::ostream& os, const X::Triangle_t& tri, unsigned short base) const;
protected:
	X::TVertexVector _vctVertex;
	X::TTriangleVector _vctTriangle;
	X::TTextureMap _mapTexture;
	X::TMeshMap _mapMesh;
};

#endif
