#ifndef __M2_H__
#define __M2_H__

#include "DataTypes.h"
#include "M2Structure.h"
#include "M2Object.h"

#endif
