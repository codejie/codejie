#include "stdafx.h"

#include "FileBuffer.h"
#include "M2FileObject.h"

int CM2FileObject::Load(const std::string& file)
{
	CFileBuffer fb;

	if(fb.Attach(file) != 0)
		return -1;

	Clear();

	if(LoadHeader(fb, _header) != 0)
		return -1;

	if(LoadName(fb, _header, _name) != 0)
		return -1;
	if(LoadSequence(fb, _header, _seq) != 0)
		return -1;
	if(LoadAnimation(fb, _header, _anim) != 0)
		return -1;
	if(LoadAnimLookup(fb, _header, _animlookup) != 0)
		return -1;
	if(LoadBone(fb, _header, _bone) != 0)
		return -1;
	if(LoadBoneLookup(fb, _header, _bonelookup) != 0)
		return -1;
	if(LoadVertex(fb, _header, _vertex) != 0)
		return -1;
	if(LoadColor(fb, _header, _color) != 0)
		return -1;
	if(LoadTexture(fb, _header, _texture) != 0)
		return -1;
	if(LoadTexFileName(fb, _texture, _texfilename) != 0)
		return -1;
	if(LoadTransparency(fb, _header, _transparency) != 0)
		return -1;
	if(LoadTexAnim(fb, _header, _texanim) != 0)
		return -1;
	if(LoadTexReplace(fb, _header, _texreplace) != 0)
		return -1;

	if(LoadRenderFlag(fb, _header, _renderflag) != 0)
		return -1;
	if(LoadBoneTable(fb, _header, _bonetable) != 0)
		return -1;
	if(LoadTexLookup(fb, _header, _texlookup) != 0)
		return -1;
	if(LoadTexTable(fb, _header, _textable) != 0)
		return -1;
	if(LoadTransLookup(fb, _header, _translookup) != 0)
		return -1;
	if(LoadTexAnimLookup(fb, _header, _texanimlookup) != 0)
		return -1;
	if(LoadBoundTriangle(fb, _header, _boundtriangle) != 0)
		return -1;
	if(LoadBoundVertex(fb, _header, _boundvertex) != 0)
		return -1;
	if(LoadBoundNormal(fb, _header, _boundnormal) != 0)
		return -1;
	if(LoadAttachment(fb, _header, _attachment) != 0)
		return -1;
	if(LoadAttachLookup(fb, _header, _attachlookup) != 0)
		return -1;
	if(LoadAttachment2(fb, _header, _attachment2) != 0)
		return -1;
	if(LoadLight(fb, _header, _light) != 0)
		return -1;
	if(LoadCamera(fb, _header, _camera) != 0)
		return -1;
	if(LoadCameraLookup(fb, _header, _cameralookup) != 0)
		return -1;
	if(LoadRibbon(fb, _header, _ribbon) != 0)
		return -1;
	if(LoadParticle(fb, _header, _particle) != 0)
		return -1;

	return 0;
}

void CM2FileObject::Clear()
{
	_header.Clear();
	_name.Clear();
	_seq.Clear();
	_anim.Clear();
	_animlookup.Clear();
	_bone.Clear();
	_bonelookup.Clear();
	_vertex.Clear();
	_color.Clear();
	_texture.Clear();
	_texfilename.Clear();
	_transparency.Clear();
	_texanim.Clear();
	_texreplace.Clear();
	_renderflag.Clear();
	_bonetable.Clear();
	_texlookup.Clear();
	_textable.Clear();
	_translookup.Clear();
	_texanimlookup.Clear();
	_boundtriangle.Clear();
	_boundvertex.Clear();
	_boundnormal.Clear();
	_attachment.Clear();
	_attachlookup.Clear();
	_attachment2.Clear();
	_light.Clear();
	_camera.Clear();
	_cameralookup.Clear();
	_ribbon.Clear();
	_particle.Clear();
}

int CM2FileObject::LoadHeader(CFileBuffer& fb, M2::THeader &header)
{
	return header.Read(fb);
}

int CM2FileObject::LoadName(CFileBuffer& fb, const M2::THeader& header, M2::TName& name)
{
	return name.Read(fb, header.m_stHeader.m_stName.offset, header.m_stHeader.m_stName.size);
}

int CM2FileObject::LoadSequence(CFileBuffer &fb, const M2::THeader &header, M2::TSequence &seq)
{
	return seq.Read(fb, header.m_stHeader.m_stSequence.offset, header.m_stHeader.m_stSequence.size);
}

int CM2FileObject::LoadAnimation(CFileBuffer &fb, const M2::THeader &header, M2::TAnimation &anim)
{
	return anim.Read(fb, header.m_stHeader.m_stAnim.offset, header.m_stHeader.m_stAnim.size);
}

int CM2FileObject::LoadAnimLookup(CFileBuffer &fb, const M2::THeader &header, M2::TAnimLookup &animlookup)
{
	return animlookup.Read(fb, header.m_stHeader.m_stAnimLookup.offset, header.m_stHeader.m_stAnimLookup.size);
}

int CM2FileObject::LoadBone(CFileBuffer &fb, const M2::THeader &header, M2::TBone &bone)
{
	return bone.Read(fb, header.m_stHeader.m_stBone.offset, header.m_stHeader.m_stBone.size);
}

int CM2FileObject::LoadBoneLookup(CFileBuffer &fb, const M2::THeader &header, M2::TBoneLookup &bonelookup)
{
	return bonelookup.Read(fb, header.m_stHeader.m_stBoneLookup.offset, header.m_stHeader.m_stBoneLookup.size);
}

int CM2FileObject::LoadVertex(CFileBuffer &fb, const M2::THeader &header, M2::TVertex &vertex)
{
	return vertex.Read(fb, header.m_stHeader.m_stVertex.offset, header.m_stHeader.m_stVertex.size);
}

int CM2FileObject::LoadColor(CFileBuffer &fb, const M2::THeader &header, M2::TColor &color)
{
	return color.Read(fb, header.m_stHeader.m_stColor.offset, header.m_stHeader.m_stColor.size);
}

int CM2FileObject::LoadTexture(CFileBuffer &fb, const M2::THeader &header, M2::TTexture &texture)
{
	return texture.Read(fb, header.m_stHeader.m_stTexture.offset, header.m_stHeader.m_stTexture.size);
}

int CM2FileObject::LoadTexFileName(CFileBuffer &fb, const M2::TTexture &texture, M2::TTexFileName &texfilename)
{
	return texfilename.Read(fb, texture);
}

int CM2FileObject::LoadTransparency(CFileBuffer &fb, const M2::THeader &header, M2::TTransparency &trans)
{
	return trans.Read(fb, header.m_stHeader.m_stTransparency.offset, header.m_stHeader.m_stTransparency.size);
}

int CM2FileObject::LoadTexAnim(CFileBuffer &fb, const M2::THeader &header, M2::TTexAnim& texture)
{
	return texture.Read(fb, header.m_stHeader.m_stTexAnim.offset, header.m_stHeader.m_stTexAnim.size);
}

int CM2FileObject::LoadTexReplace(CFileBuffer &fb, const M2::THeader &header, M2::TTexReplace& texture)
{
	return texture.Read(fb, header.m_stHeader.m_stTexReplace.offset, header.m_stHeader.m_stTexReplace.size);
}

int CM2FileObject::LoadRenderFlag(CFileBuffer &fb, const M2::THeader &header, M2::TRenderFlag& render)
{
	return render.Read(fb, header.m_stHeader.m_stRenderFlag.offset, header.m_stHeader.m_stRenderFlag.size);
}

int CM2FileObject::LoadBoneTable(CFileBuffer &fb, const M2::THeader &header, M2::TBoneTable& bonetable)
{
	return bonetable.Read(fb, header.m_stHeader.m_stBoneTable.offset, header.m_stHeader.m_stBoneTable.size);
}

int CM2FileObject::LoadTexLookup(CFileBuffer &fb, const M2::THeader &header, M2::TTexLookup& texlookup)
{
	return texlookup.Read(fb, header.m_stHeader.m_stTexLookup.offset, header.m_stHeader.m_stTexLookup.size);
}

int CM2FileObject::LoadTexTable(CFileBuffer &fb, const M2::THeader &header, M2::TTexTable& textable)
{
	return textable.Read(fb, header.m_stHeader.m_stTexTable.offset, header.m_stHeader.m_stTexTable.size);
}

int CM2FileObject::LoadTransLookup(CFileBuffer &fb, const M2::THeader &header, M2::TTransLookup& translookup)
{
	return translookup.Read(fb, header.m_stHeader.m_stTransLookup.offset, header.m_stHeader.m_stTransLookup.size);
}

int CM2FileObject::LoadTexAnimLookup(CFileBuffer &fb, const M2::THeader &header, M2::TTexAnimLookup& texanimlookup)
{
	return texanimlookup.Read(fb, header.m_stHeader.m_stTexAnimLookup.offset, header.m_stHeader.m_stTexAnimLookup.size);
}

int CM2FileObject::LoadBoundTriangle(CFileBuffer &fb, const M2::THeader &header, M2::TBoundTriangle& boundtriangle)
{
	return boundtriangle.Read(fb, header.m_stHeader.m_stBoundTriangle.offset, header.m_stHeader.m_stBoundTriangle.size);
}

int CM2FileObject::LoadBoundVertex(CFileBuffer &fb, const M2::THeader &header, M2::TBoundVertex& boundvertex)
{
	return boundvertex.Read(fb, header.m_stHeader.m_stBoundVertex.offset, header.m_stHeader.m_stBoundVertex.size);
}

int CM2FileObject::LoadBoundNormal(CFileBuffer &fb, const M2::THeader &header, M2::TBoundNormal& boundnormal)
{
	return boundnormal.Read(fb, header.m_stHeader.m_stBoundNormal.offset, header.m_stHeader.m_stBoundNormal.size);
}

int CM2FileObject::LoadAttachment(CFileBuffer &fb, const M2::THeader &header, M2::TAttachment& attach)
{
	return attach.Read(fb, header.m_stHeader.m_stAttachment.offset, header.m_stHeader.m_stAttachment.size);
}

int CM2FileObject::LoadAttachLookup(CFileBuffer &fb, const M2::THeader &header, M2::TAttachLookup& attach)
{
	return attach.Read(fb, header.m_stHeader.m_stAttachLookup.offset, header.m_stHeader.m_stAttachLookup.size);
}

int CM2FileObject::LoadAttachment2(CFileBuffer &fb, const M2::THeader &header, M2::TAttachment2& attach)
{
	return attach.Read(fb, header.m_stHeader.m_stAttachment2.offset, header.m_stHeader.m_stAttachment2.size);
}

int CM2FileObject::LoadLight(CFileBuffer &fb, const M2::THeader &header, M2::TLight& light)
{
	return light.Read(fb, header.m_stHeader.m_stLight.offset, header.m_stHeader.m_stLight.size);
}

int CM2FileObject::LoadCamera(CFileBuffer &fb, const M2::THeader &header, M2::TCamera& camera)
{
	return camera.Read(fb, header.m_stHeader.m_stCamera.offset, header.m_stHeader.m_stCamera.size);
}

int CM2FileObject::LoadCameraLookup(CFileBuffer &fb, const M2::THeader &header, M2::TCameraLookup& camera)
{
	return camera.Read(fb, header.m_stHeader.m_stCameraLookup.offset, header.m_stHeader.m_stCameraLookup.size);
}

int CM2FileObject::LoadRibbon(CFileBuffer &fb, const M2::THeader &header, M2::TRibbon& ribbon)
{
	return ribbon.Read(fb, header.m_stHeader.m_stRibbon.offset, header.m_stHeader.m_stRibbon.size);
}

int CM2FileObject::LoadParticle(CFileBuffer &fb, const M2::THeader &header, M2::TParticle& particle)
{
	return particle.Read(fb, header.m_stHeader.m_stParticle.offset, header.m_stHeader.m_stParticle.size);
}
