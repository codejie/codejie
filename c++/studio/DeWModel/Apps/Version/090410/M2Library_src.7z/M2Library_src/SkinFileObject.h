#ifndef __SKINFILEOBJECT_H__
#define __SKINFILEOBJECT_H__

#include <string>

#include "SkinStructure.h"

class CSkinFileObject
{
public:
	CSkinFileObject() {}
	virtual ~CSkinFileObject() {}

	int Load(const std::string& file);
protected:
	void Clear();
	int LoadHeader(CFileBuffer& fb, Skin::THeader& header);
	int LoadIndex(CFileBuffer& fb, const Skin::THeader& header, Skin::TIndex& index);
	int LoadTriangle(CFileBuffer& fb, const Skin::THeader& header, Skin::TTriangle& triangle);
	int LoadProperty(CFileBuffer& fb, const Skin::THeader& header, Skin::TProperty& property);
	int LoadSubMesh(CFileBuffer& fb, const Skin::THeader& header, Skin::TSubMesh& submesh);
	int LoadTexture(CFileBuffer& fb, const Skin::THeader& header, Skin::TTexture& texture);
public:
	Skin::THeader _header;
	Skin::TIndex _index;
	Skin::TTriangle _triangle;
	Skin::TProperty _property;
	Skin::TSubMesh _submesh;
	Skin::TTexture _texture;
};

#endif
