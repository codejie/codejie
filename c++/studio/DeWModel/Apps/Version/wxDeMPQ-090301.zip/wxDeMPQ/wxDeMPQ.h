#ifndef __WXDEMPQ_H__
#define __WXDEMPQ_H__

#include "wx/wx.h"
#include "MainFrame.h"

class CwxDeMPQApp : public wxApp
{
public:
	bool OnInit();
};

#endif