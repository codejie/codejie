#ifndef __NOTEBOOKPANELS_H__
#define __NOTEBOOKPANELS_H__

#include <map>

#include "MPQDataObject.h"
#include "MPQDBCFieldObject.h"

class wxToolbook;
class wxPanel;
class wxStaticBox;
class wxStaticText;
class wxTextCtrl;
class wxGrid;
class wxButton;
class wxString;

class CNotebookPanel;

enum PanelType { PT_INFO = 0, PT_DATA, PT_DBC, PT_BLP };

class CNotebookPanelManager
{
private:
	struct PanelData_t
	{
		PanelData_t(size_t pos, CNotebookPanel* panel)
			: m_szPos(pos), m_objPanel(panel)
		{
		}
		size_t m_szPos;
		CNotebookPanel* m_objPanel;
	};
	typedef std::map<PanelType, PanelData_t> TPanelMap;
public:
	CNotebookPanelManager();
	virtual ~CNotebookPanelManager();

	int InitPanels(wxToolbook* notebook);
	
	CNotebookPanel* ShowPanel(PanelType type, bool show, bool selected = true);

	CNotebookPanel* GetPanel(PanelType type);
protected:
	void DestoryPanels();
private:
	wxToolbook* _ctrlNotebook;
	TPanelMap _mapPanel;
};

class CNotebookPanel
{
public:
	CNotebookPanel(PanelType type, const wxString& title, int image = 0, int id = wxID_ANY);
	virtual ~CNotebookPanel();

	int InitControls(wxToolbook* notebook);
protected:
	virtual int CreatePanelControls() = 0;
	virtual int SetPanelControls() = 0;
public:
	PanelType m_eType;
	wxString m_strTitle;
	int m_iImageID;
	int m_iPanelID;
	wxPanel* m_ctrlPanel;
};

class CNotebookInfoPanel : public CNotebookPanel
{
public:
	CNotebookInfoPanel();
	virtual ~CNotebookInfoPanel();

	void DisplayInfo(const MPQData::TFileData *data);
protected:
	virtual int CreatePanelControls();
	virtual int SetPanelControls();
private:
	wxStaticBox* sizer_16_staticbox;
	wxStaticBox* sizer_6_staticbox;
	wxStaticText* m_labelFileName;
	wxStaticText* label_8;
    wxTextCtrl* m_editInfoFileName;
    wxStaticText* label_9;
    wxTextCtrl* m_editInfoOffset;
    wxStaticText* label_10;
    wxTextCtrl* m_editInfoVersion;
    wxStaticText* label_11;
    wxTextCtrl* m_editInfoSize;
    wxStaticText* label_12;
    wxTextCtrl* m_editInfoFlag;
    wxStaticText* label_13;
    wxTextCtrl* m_editInfoIndex;
    wxStaticText* label_14;
    wxTextCtrl* m_editInfoCompSize;
    wxButton* m_btnInfoExport;
    wxPanel* panel_1;
};

class CNotebookDataPanel : public CNotebookPanel
{
public:
	CNotebookDataPanel();
	virtual ~CNotebookDataPanel();

	bool CheckDataFileName(const wxString& file) const;
	void SetDataFileName(const wxString& str);

	void Refresh(const wxString& str);
	void AppendEnd();
	void AppendData(const wxString& str);
protected:
	virtual int CreatePanelControls();
	virtual int SetPanelControls();
private:
	wxStaticBox* sizer_15_staticbox;
    wxStaticText* m_labelDataFileName;
    wxTextCtrl* m_ctrlDataText;
};


class CNotebookDBCPanel : public CNotebookPanel
{
public:
	CNotebookDBCPanel();
	virtual ~CNotebookDBCPanel();

	void SetFileName(const wxString& str);
	void SetHeaderInfo(const MPQData::CDBCHeader& header);
	void InitGrid(int fields, const CMPQDBCFieldManager::TFieldMap* mapField);
	void AppendRow();
	void SetGridData(int row, int col, const wxString& data);
protected:
	virtual int CreatePanelControls();
	virtual int SetPanelControls();
private:
    wxStaticBox* sizer_6_staticbox;
    wxStaticBox* sizer_3_staticbox;
    wxStaticText* m_labelFileName;
    wxStaticText* label_6;
    wxTextCtrl* m_editSignature;
    wxStaticText* label_8;
    wxTextCtrl* m_editRecords;
    wxStaticText* label_9;
    wxTextCtrl* m_editFields;
    wxStaticText* label_7;
    wxTextCtrl* m_editRecordSize;
    wxStaticText* label_10;
    wxTextCtrl* m_editStringSize;
    wxPanel* panel_2;
    wxPanel* panel_3;
    wxGrid* m_ctrlGrid;
};

class CNotebookBLPPanel : public CNotebookPanel
{
protected:
	class CScrolledBitmapCanvas : public wxScrolledWindow
	{
	public:
		CScrolledBitmapCanvas(wxWindow *parent, wxWindowID id, const wxPoint &pos, const wxSize &size);
		virtual ~CScrolledBitmapCanvas();

		void OnPaint(wxPaintEvent &event);

		int SetBitmap(const wxString& file, wxSize& size);

		int InitPNGHandler();
	protected:
		wxBitmap _bitmapPNG;
	private:
		DECLARE_EVENT_TABLE()
	};
public:
	CNotebookBLPPanel();
	virtual ~CNotebookBLPPanel();

	void SetFileName(const wxString& str);
	int ShowImage(const wxString& file);
protected:
	virtual int CreatePanelControls();
	virtual int SetPanelControls();
private:
    wxStaticBox* sizer_3_staticbox;
    wxStaticText* m_labelFileName;
    CScrolledBitmapCanvas* m_canvasBitmap;
};

#endif
