
#include "wx/wx.h"
#include "wx/panel.h"
#include "wx/notebook.h"
#include "wx/toolbook.h"
#include "wx/grid.h"

#include "NotebookPanels.h"

CNotebookPanelManager::CNotebookPanelManager()
: _ctrlNotebook(NULL)
{
}

CNotebookPanelManager::~CNotebookPanelManager()
{
	DestoryPanels();
}

void CNotebookPanelManager::DestoryPanels()
{
}

int CNotebookPanelManager::InitPanels(wxToolbook *notebook)
{
	_ctrlNotebook = notebook;

	return 0;
}

void CNotebookPanelManager::ShowPanel(PanelType type, bool show, bool selected)
{
	if(_ctrlNotebook == NULL)
		return;

	TPanelMap::iterator it = _mapPanel.find(type);
	if(show)
	{
		if(it == _mapPanel.end())
		{
			CNotebookPanel* panel = NULL;
			switch(type)
			{
			case PT_INFO:
				panel = new CNotebookInfoPanel();
				break;
			case PT_DATA:
				panel = new CNotebookDataPanel();
				break;
			case PT_DBC:
				panel = new CNotebookDBCPanel();
				break;
			default:
				return;
			}
			panel->InitControls(_ctrlNotebook);
			_ctrlNotebook->AddPage(panel->m_ctrlPanel, panel->m_strTitle, false, panel->m_iImageID);
			PanelData_t data(_ctrlNotebook->GetPageCount() - 1, panel);
			it = _mapPanel.insert(std::make_pair(type, data)).first;
		}
		if(selected)
			_ctrlNotebook->SetSelection(it->second.m_szPos);
	}
	else
	{
		if(it != _mapPanel.end())
		{
			_ctrlNotebook->DeletePage(it->second.m_szPos);
			delete it->second.m_objPanel;
			_mapPanel.erase(it);
		}
	}
}

CNotebookPanel* CNotebookPanelManager::GetPanel(PanelType type)
{
	if(_ctrlNotebook == NULL)
		return NULL;

	TPanelMap::iterator it = _mapPanel.find(type);
	if(it == _mapPanel.end())
		return NULL;

	return it->second.m_objPanel;
}

////

CNotebookPanel::CNotebookPanel(PanelType type, const wxString& title, int image, int id)
: m_eType(type)
, m_strTitle(title)
, m_iImageID(image)
, m_iPanelID(id)
, m_ctrlPanel(NULL)
{
}

CNotebookPanel::~CNotebookPanel()
{
	//if(m_ctrlPanel != NULL)
	//	delete m_ctrlPanel;
}

int CNotebookPanel::InitControls(wxToolbook* notebook)
{
	m_ctrlPanel = new wxPanel(notebook, m_iPanelID);

	if(CreatePanelControls() == 0 && SetPanelControls() == 0)
		return 0;

	return -1;
}

////
CNotebookInfoPanel::CNotebookInfoPanel()
: CNotebookPanel(PT_INFO, wxT("Information"), 0)
{
}

CNotebookInfoPanel::~CNotebookInfoPanel()
{
}

int CNotebookInfoPanel::CreatePanelControls()
{
	sizer_6_staticbox = new wxStaticBox(m_ctrlPanel, -1, wxEmptyString);
	label_8 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("FileName : "), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editInfoFileName = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_READONLY);
    label_9 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("Offset : "), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editInfoOffset = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_READONLY);
    label_10 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("Version : "), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editInfoVersion = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_READONLY);
    label_11 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("Size : "), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editInfoSize = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_READONLY);
    label_12 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("Flag : "), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editInfoFlag = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_READONLY);
    label_13 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("Index : "), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editInfoIndex = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_READONLY);
    label_14 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("CompSize : "), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editInfoCompSize = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_READONLY);
    m_btnInfoExport = new wxButton(m_ctrlPanel, wxID_ANY, wxT("Export ..."));
    panel_1 = new wxPanel(m_ctrlPanel, wxID_ANY);

	return 0;
}

int CNotebookInfoPanel::SetPanelControls()
{
    wxBoxSizer* sizer_5 = new wxBoxSizer(wxVERTICAL);
    wxStaticBoxSizer* sizer_6 = new wxStaticBoxSizer(sizer_6_staticbox, wxHORIZONTAL);
    wxBoxSizer* sizer_7 = new wxBoxSizer(wxVERTICAL);
    wxBoxSizer* sizer_14 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer* sizer_13 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer* sizer_12 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer* sizer_11 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer* sizer_10 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer* sizer_9 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer* sizer_8 = new wxBoxSizer(wxHORIZONTAL);

	sizer_8->Add(label_8, 2, wxLEFT|wxALIGN_CENTER_VERTICAL, 4);
    sizer_8->Add(m_editInfoFileName, 8, wxRIGHT, 16);
    sizer_7->Add(sizer_8, 0, wxBOTTOM|wxEXPAND, 4);
    sizer_9->Add(label_9, 2, wxLEFT|wxALIGN_CENTER_VERTICAL, 4);
    sizer_9->Add(m_editInfoOffset, 8, wxRIGHT, 16);
    sizer_7->Add(sizer_9, 0, wxBOTTOM|wxEXPAND, 4);
    sizer_10->Add(label_10, 2, wxLEFT|wxALIGN_CENTER_VERTICAL, 4);
    sizer_10->Add(m_editInfoVersion, 8, wxRIGHT, 16);
    sizer_7->Add(sizer_10, 0, wxBOTTOM|wxEXPAND, 4);
    sizer_11->Add(label_11, 2, wxLEFT|wxALIGN_CENTER_VERTICAL, 4);
    sizer_11->Add(m_editInfoSize, 8, wxRIGHT, 16);
    sizer_7->Add(sizer_11, 0, wxBOTTOM|wxEXPAND, 4);
    sizer_12->Add(label_12, 2, wxLEFT|wxALIGN_CENTER_VERTICAL, 4);
    sizer_12->Add(m_editInfoFlag, 8, wxRIGHT, 16);
    sizer_7->Add(sizer_12, 0, wxBOTTOM|wxEXPAND, 4);
    sizer_13->Add(label_13, 2, wxLEFT|wxALIGN_CENTER_VERTICAL, 4);
    sizer_13->Add(m_editInfoIndex, 8, wxRIGHT, 16);
    sizer_7->Add(sizer_13, 0, wxBOTTOM|wxEXPAND, 4);
    sizer_14->Add(label_14, 2, wxLEFT|wxALIGN_CENTER_VERTICAL, 4);
    sizer_14->Add(m_editInfoCompSize, 8, wxRIGHT, 16);
    sizer_7->Add(sizer_14, 0, wxBOTTOM|wxEXPAND, 4);
    sizer_6->Add(sizer_7, 1, wxEXPAND, 0);
    sizer_5->Add(sizer_6, 0, wxEXPAND, 0);
    sizer_5->Add(m_btnInfoExport, 0, wxTOP|wxBOTTOM|wxEXPAND, 4);
    sizer_5->Add(panel_1, 1, wxEXPAND, 0);
    m_ctrlPanel->SetSizer(sizer_5);

	m_ctrlPanel->Layout();

	return 0;
}

////

CNotebookDataPanel::CNotebookDataPanel()
: CNotebookPanel(PT_DATA, wxT("Data Dump"), 0)
{
}

CNotebookDataPanel::~CNotebookDataPanel()
{
}

int CNotebookDataPanel::CreatePanelControls()
{
	sizer_15_staticbox = new wxStaticBox(m_ctrlPanel, -1, wxEmptyString);
    m_labelDataFileName = new wxStaticText(m_ctrlPanel, wxID_ANY, wxEmptyString);
    m_ctrlDataText = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_MULTILINE|wxTE_READONLY|wxHSCROLL);

	return 0;
}

int CNotebookDataPanel::SetPanelControls()
{
    wxBoxSizer* sizer_4 = new wxBoxSizer(wxVERTICAL);
    wxStaticBoxSizer* sizer_15 = new wxStaticBoxSizer(sizer_15_staticbox, wxHORIZONTAL);
 
	sizer_15->Add(m_labelDataFileName, 0, wxEXPAND|wxALIGN_RIGHT|wxALIGN_CENTER_VERTICAL, 0);
    sizer_4->Add(sizer_15, 0, wxBOTTOM|wxEXPAND, 4);
    sizer_4->Add(m_ctrlDataText, 1, wxEXPAND, 0);
    m_ctrlPanel->SetSizer(sizer_4);

    m_ctrlDataText->SetFont(wxFont(10, wxMODERN, wxNORMAL, wxNORMAL, 0, wxT("Courier New")));

	m_ctrlPanel->Layout();

	return 0;
}

////

CNotebookDBCPanel::CNotebookDBCPanel()
: CNotebookPanel(PT_DBC, wxT("DBC"), 0)
{
}

CNotebookDBCPanel::~CNotebookDBCPanel()
{
}

int CNotebookDBCPanel::CreatePanelControls()
{
    sizer_3_staticbox = new wxStaticBox(m_ctrlPanel, -1, wxT("Info"));
    label_1 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("Signature:"), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editSigature = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString);
    label_2 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("Records:"), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editRecords = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString);
    label_3 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("Fields:"), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editFields = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString);
    label_4 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("Record Size:"), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editRecordSize = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString);
    label_5 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("String Block Size:"), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editBlockSize = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString);
    panel_1 = new wxPanel(m_ctrlPanel, wxID_ANY);
    panel_2 = new wxPanel(m_ctrlPanel, wxID_ANY);
    m_ctrlGrid = new wxGrid(m_ctrlPanel, wxID_ANY);

	return 0;
}

int CNotebookDBCPanel::SetPanelControls()
{
    m_ctrlGrid->CreateGrid(0, 1);
    m_ctrlGrid->SetRowLabelSize(30);
    m_ctrlGrid->EnableEditing(false);
    m_ctrlGrid->SetGridLineColour(wxColour(0, 0, 255));
    m_ctrlGrid->SetSelectionMode(wxGrid::wxGridSelectRows);
    m_ctrlGrid->SetColLabelValue(0, wxEmptyString);

	wxBoxSizer* sizer_1 = new wxBoxSizer(wxVERTICAL);
    wxBoxSizer* sizer_2 = new wxBoxSizer(wxVERTICAL);
    wxStaticBoxSizer* sizer_3 = new wxStaticBoxSizer(sizer_3_staticbox, wxVERTICAL);
    wxBoxSizer* sizer_5 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer* sizer_4 = new wxBoxSizer(wxHORIZONTAL);
    sizer_4->Add(label_1, 1, wxEXPAND|wxALIGN_CENTER_VERTICAL, 0);
    sizer_4->Add(m_editSigature, 2, wxEXPAND, 0);
    sizer_4->Add(label_2, 1, wxEXPAND|wxALIGN_CENTER_VERTICAL, 0);
    sizer_4->Add(m_editRecords, 2, wxEXPAND, 0);
    sizer_4->Add(label_3, 1, wxEXPAND|wxALIGN_CENTER_VERTICAL, 0);
    sizer_4->Add(m_editFields, 2, wxEXPAND, 0);
    sizer_3->Add(sizer_4, 0, wxEXPAND, 0);
    sizer_5->Add(label_4, 3, wxEXPAND|wxALIGN_CENTER_VERTICAL, 0);
    sizer_5->Add(m_editRecordSize, 4, wxEXPAND, 0);
    sizer_5->Add(label_5, 4, wxEXPAND|wxALIGN_CENTER_VERTICAL, 0);
    sizer_5->Add(m_editBlockSize, 4, wxEXPAND, 0);
    sizer_5->Add(panel_1, 1, wxEXPAND, 0);
    sizer_5->Add(panel_2, 1, wxEXPAND, 0);
    sizer_3->Add(sizer_5, 0, wxEXPAND, 0);
    sizer_2->Add(sizer_3, 0, wxEXPAND, 0);
    sizer_2->Add(m_ctrlGrid, 1, wxEXPAND, 0);

    m_ctrlPanel->SetSizer(sizer_2);

	m_ctrlPanel->Layout();

	return 0;
}




