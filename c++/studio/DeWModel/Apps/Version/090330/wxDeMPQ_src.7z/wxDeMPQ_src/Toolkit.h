#ifndef __TOOLKIT_H__
#define __TOOLKIT_H__

#include <string>
#include "wx/wx.h"

namespace Toolkit
{

inline const std::string wxString2String(const wxString& str)
{
	char ch[1024];
//		memset(ch, 0, 1024);
	strcpy(ch, (const char*)str.mb_str(wxConvUTF8));
	return std::string(ch);
}

inline const wxString String2wxString(const std::string& str)
{
	return wxString(str.c_str(), wxConvUTF8);
}
	
}

#endif
