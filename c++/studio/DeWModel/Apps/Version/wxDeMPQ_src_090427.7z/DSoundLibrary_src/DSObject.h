#ifndef __DSOBJECT_H__
#define __DSOBJECT_H__

#include "DSoundObject.h"
#include "DSWaveObject.h"
#include "DSMP3Object.h"

#endif
