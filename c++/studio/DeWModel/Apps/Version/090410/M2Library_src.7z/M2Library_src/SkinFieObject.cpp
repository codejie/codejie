#include "stdafx.h"

#include "FileBuffer.h"
#include "SkinFileObject.h"

int CSkinFileObject::Load(const std::string &file)
{
	CFileBuffer fb;

	if(fb.Attach(file) != 0)
		return -1;

	Clear();

	if(LoadHeader(fb, _header) != 0)
		return -1;
	
	if(LoadIndex(fb, _header, _index) != 0)
		return -1;
	if(LoadTriangle(fb, _header, _triangle) != 0)
		return -1;
	if(LoadProperty(fb, _header, _property) != 0)
		return -1;
	if(LoadSubMesh(fb, _header, _submesh) != 0)
		return -1;
	if(LoadTexture(fb, _header, _texture) != 0)
		return -1;

	return 0;
}

void CSkinFileObject::Clear()
{
	_header.Clear();
	_index.Clear();
	_triangle.Clear();
	_property.Clear();
	_submesh.Clear();
	_texture.Clear();
}

int CSkinFileObject::LoadHeader(CFileBuffer &fb, Skin::THeader &header)
{
	return header.Read(fb);
}

int CSkinFileObject::LoadIndex(CFileBuffer &fb, const Skin::THeader& header, Skin::TIndex &index)
{
	return index.Read(fb, header.m_stHeader.m_stIndex.offset, header.m_stHeader.m_stIndex.size);
}

int CSkinFileObject::LoadTriangle(CFileBuffer &fb, const Skin::THeader &header, Skin::TTriangle &triangle)
{
	return triangle.Read(fb, header.m_stHeader.m_stTriangle.offset, header.m_stHeader.m_stTriangle.size);
}

int CSkinFileObject::LoadProperty(CFileBuffer &fb, const Skin::THeader &header, Skin::TProperty &property)
{
	return property.Read(fb, header.m_stHeader.m_stProperty.offset, header.m_stHeader.m_stProperty.size);
}

int CSkinFileObject::LoadSubMesh(CFileBuffer &fb, const Skin::THeader &header, Skin::TSubMesh &submesh)
{
	return submesh.Read(fb, header.m_stHeader.m_stSubMesh.offset, header.m_stHeader.m_stSubMesh.size);
}

int CSkinFileObject::LoadTexture(CFileBuffer &fb, const Skin::THeader &header, Skin::TTexture &texture)
{
	return texture.Read(fb, header.m_stHeader.m_stTexture.offset, header.m_stHeader.m_stTexture.size);
}