
#include "wxDeMPQ.h"

IMPLEMENT_APP(CwxDeMPQApp)

bool CwxDeMPQApp::OnInit()
{
	wxInitAllImageHandlers(); 
	CMainFrame* MainFrame = new CMainFrame(NULL, wxID_ANY, wxEmptyString);
    MainFrame->Show();

    SetTopWindow(MainFrame);
	return true;
}