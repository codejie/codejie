#ifndef __MODELOBJECT_H__
#define __MODELOBJECT_H__

#include <string>

#include "M2Object.h"
#include "SkinObject.h"

#ifdef MODELLIBRARY_EXPORTS
#define MODELLIBRARY_API __declspec(dllexport)
#else
#define MODELLIBRARY_API __declspec(dllimport)
#endif


class MODELLIBRARY_API CModelObject
{
public:
	CModelObject();
	virtual ~CModelObject();

	int Init(const std::wstring& path, bool findmpq = true);

	int LoadModel(const std::wstring& mpq, const std::wstring& m2);
	int ToXFile(const std::wstring& file);
private:
	int LoadM2Object(const std::wstring& mpq, const std::wstring& file);
	int LoadSkinObject(const std::wstring& mpq, const std::wstring& file);
	int ExtractBLPFile(const std::wstring& mpq, const std::wstring& blp, const std::wstring& png);
private:
	std::wstring _strMPQ;
	std::wstring _strM2;
	CM2Object _objM2;
	CSkinObject _objSkin;
private:
	bool _bFindMPQ;
	typedef std::vector<std::wstring> TMPQVector;
	TMPQVector _vctMPQ;
private:
	int ScanMPQPath(const std::wstring& path);
};

#endif
