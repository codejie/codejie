#ifndef __NOTEBOOKPANELS_H__
#define __NOTEBOOKPANELS_H__

#include <map>

class wxToolbook;
class wxPanel;
class wxStaticBox;
class wxStaticText;
class wxTextCtrl;
class wxGrid;
class wxButton;

class CNotebookPanel;

enum PanelType { PT_INFO, PT_DATA, PT_DBC };

class CNotebookPanelManager
{
private:
	struct PanelData_t
	{
		PanelData_t(size_t pos, CNotebookPanel* panel)
			: m_szPos(pos), m_objPanel(panel)
		{
		}
		size_t m_szPos;
		CNotebookPanel* m_objPanel;
	};
	typedef std::map<PanelType, PanelData_t> TPanelMap;
public:
	CNotebookPanelManager();
	virtual ~CNotebookPanelManager();

	int InitPanels(wxToolbook* notebook);
	
	void ShowPanel(PanelType type, bool show, bool selected = true);

	CNotebookPanel* GetPanel(PanelType type);
protected:
	void DestoryPanels();
private:
	wxToolbook* _ctrlNotebook;
	TPanelMap _mapPanel;
};

class CNotebookPanel
{
public:
	CNotebookPanel(PanelType type, const wxString& title, int image = 0, int id = wxID_ANY);
	virtual ~CNotebookPanel();

	int InitControls(wxToolbook* notebook);
protected:
	virtual int CreatePanelControls() = 0;
	virtual int SetPanelControls() = 0;
public:
	PanelType m_eType;
	wxString m_strTitle;
	int m_iImageID;
	int m_iPanelID;
	wxPanel* m_ctrlPanel;
};

class CNotebookInfoPanel : public CNotebookPanel
{
public:
	CNotebookInfoPanel();
	virtual ~CNotebookInfoPanel();

protected:
	virtual int CreatePanelControls();
	virtual int SetPanelControls();
private:
	wxStaticBox* sizer_6_staticbox;
	wxStaticText* label_8;
    wxTextCtrl* m_editInfoFileName;
    wxStaticText* label_9;
    wxTextCtrl* m_editInfoOffset;
    wxStaticText* label_10;
    wxTextCtrl* m_editInfoVersion;
    wxStaticText* label_11;
    wxTextCtrl* m_editInfoSize;
    wxStaticText* label_12;
    wxTextCtrl* m_editInfoFlag;
    wxStaticText* label_13;
    wxTextCtrl* m_editInfoIndex;
    wxStaticText* label_14;
    wxTextCtrl* m_editInfoCompSize;
    wxButton* m_btnInfoExport;
    wxPanel* panel_1;
};

class CNotebookDataPanel : public CNotebookPanel
{
public:
	CNotebookDataPanel();
	virtual ~CNotebookDataPanel();

protected:
	virtual int CreatePanelControls();
	virtual int SetPanelControls();
private:
	wxStaticBox* sizer_15_staticbox;
    wxStaticText* m_labelDataFileName;
    wxTextCtrl* m_ctrlDataText;
};

class CNotebookDBCPanel : public CNotebookPanel
{
public:
	CNotebookDBCPanel();
	virtual ~CNotebookDBCPanel();

protected:
	virtual int CreatePanelControls();
	virtual int SetPanelControls();
private:
    wxStaticBox* sizer_3_staticbox;
    wxStaticText* label_1;
    wxTextCtrl* m_editSigature;
    wxStaticText* label_2;
    wxTextCtrl* m_editRecords;
    wxStaticText* label_3;
    wxTextCtrl* m_editFields;
    wxStaticText* label_4;
    wxTextCtrl* m_editRecordSize;
    wxStaticText* label_5;
    wxTextCtrl* m_editBlockSize;
    wxPanel* panel_1;
    wxPanel* panel_2;
    wxGrid* m_ctrlGrid;
};

#endif
