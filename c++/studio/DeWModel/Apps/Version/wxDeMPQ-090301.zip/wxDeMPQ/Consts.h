#ifndef __CONSTS_H__
#define __CONSTS_H__

const int ID_BASE	=	100;

const int IDM_FILE_EXIT		=	ID_BASE + 1;
const int IDM_HELP_ABOUT	=	ID_BASE + 2;
const int IDM_PARSER_DBC	=	ID_BASE + 3;
const int IDM_HELP_TEST		=	ID_BASE + 4;

const int IDT_BUTTON_OPEN	=	ID_BASE + 101;
const int IDT_BUTTON_RELOAD	=	ID_BASE + 102;

const int IDC_TREE			=	ID_BASE + 1001;
const int IDC_NOTEBOOK		=	ID_BASE + 1002;
const int IDC_COMBO			=	ID_BASE + 1003;
#endif