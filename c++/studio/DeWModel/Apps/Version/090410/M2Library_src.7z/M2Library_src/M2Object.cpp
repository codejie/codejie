#include "stdafx.h"

#include "XFileObject.h"

#include "M2Object.h"

CM2Object::CM2Object()
{
}

CM2Object::~CM2Object()
{
}

int CM2Object::Load(const std::string& file)
{
	std::string skinfile = file;
	std::string::size_type pos = skinfile.find(".");
	if(pos == std::string::npos)
		return -1;
	skinfile = skinfile.substr(0, pos);
	skinfile += "00.skin";

	if(LoadM2File(file) != 0)
		return -1;
	if(LoadSkinFile(skinfile) != 0)
		return -1;
	return 0;
}

int CM2Object::ToXFile(const std::string &file) const
{
	CXFileObject x;

	return x.Output(_objM2, _objSkin, file);
}

int CM2Object::LoadM2File(const std::string& file)
{
	return _objM2.Load(file);
}

int CM2Object::LoadSkinFile(const std::string& file)
{
	return _objSkin.Load(file);
}

