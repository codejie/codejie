#ifndef __DATADEFS_H__
#define __DATADEFS_H__

#include <string>

struct TFileData
{
	std::string m_strName;
    const char* m_pPointer;
    unsigned int m_uiVersion;
	unsigned int m_uiSize;
	unsigned int m_uiFlag;
	unsigned int m_uiIndex;
	unsigned int m_uiCompSize;
};

#endif
