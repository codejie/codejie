
#include "wx/wx.h"
#include "wx/panel.h"
#include "wx/notebook.h"
#include "wx/toolbook.h"
#include "wx/grid.h"

#include "Consts.h"
#include "Toolkit.h"

#include "NotebookPanels.h"

CNotebookPanelManager::CNotebookPanelManager()
: _ctrlNotebook(NULL)
{
}

CNotebookPanelManager::~CNotebookPanelManager()
{
	DestoryPanels();
}

void CNotebookPanelManager::DestoryPanels()
{
}

int CNotebookPanelManager::InitPanels(wxToolbook *notebook)
{
	_ctrlNotebook = notebook;

	return 0;
}

CNotebookPanel* CNotebookPanelManager::ShowPanel(PanelType type, bool show, bool selected)
{
	if(_ctrlNotebook == NULL)
		return NULL;

	TPanelMap::iterator it = _mapPanel.find(type);
	if(show)
	{
		CNotebookPanel* panel = NULL;
		if(it == _mapPanel.end())
		{
			switch(type)
			{
			case PT_INFO:
				panel = new CNotebookInfoPanel();
				break;
			case PT_DATA:
				panel = new CNotebookDataPanel();
				break;
			case PT_DBC:
				panel = new CNotebookDBCPanel();
				break;
			case PT_BLP:
				panel = new CNotebookBLPPanel();
				break;
			default:
				return NULL;
			}
			panel->InitControls(_ctrlNotebook);
			_ctrlNotebook->AddPage(panel->m_ctrlPanel, panel->m_strTitle, false, panel->m_iImageID);
			PanelData_t data(_ctrlNotebook->GetPageCount() - 1, panel);
			it = _mapPanel.insert(std::make_pair(type, data)).first;
		}
		if(selected)
			_ctrlNotebook->SetSelection(it->second.m_szPos);
		return it->second.m_objPanel;
	}
	else
	{
		if(it != _mapPanel.end())
		{
			_ctrlNotebook->DeletePage(it->second.m_szPos);
			delete it->second.m_objPanel;
			_mapPanel.erase(it);
		}
	}
	return NULL;
}

CNotebookPanel* CNotebookPanelManager::GetPanel(PanelType type)
{
	if(_ctrlNotebook == NULL)
		return NULL;

	TPanelMap::iterator it = _mapPanel.find(type);
	if(it == _mapPanel.end())
		return NULL;

	return it->second.m_objPanel;
}

////

CNotebookPanel::CNotebookPanel(PanelType type, const wxString& title, int image, int id)
: m_eType(type)
, m_strTitle(title)
, m_iImageID(image)
, m_iPanelID(id)
, m_ctrlPanel(NULL)
{
}

CNotebookPanel::~CNotebookPanel()
{
	//if(m_ctrlPanel != NULL)
	//	delete m_ctrlPanel;
}

int CNotebookPanel::InitControls(wxToolbook* notebook)
{
	m_ctrlPanel = new wxPanel(notebook, m_iPanelID);

	if(CreatePanelControls() == 0 && SetPanelControls() == 0)
		return 0;

	return -1;
}

////
CNotebookInfoPanel::CNotebookInfoPanel()
: CNotebookPanel(PT_INFO, wxT("Information"), 0)
{
}

CNotebookInfoPanel::~CNotebookInfoPanel()
{
}

int CNotebookInfoPanel::CreatePanelControls()
{
    sizer_16_staticbox = new wxStaticBox(m_ctrlPanel, -1, wxEmptyString);
	sizer_6_staticbox = new wxStaticBox(m_ctrlPanel, -1, wxEmptyString);

    m_labelFileName = new wxStaticText(m_ctrlPanel, wxID_ANY, wxEmptyString);

	label_8 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("FileName : "), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editInfoFileName = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_READONLY);
    label_9 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("Offset : "), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editInfoOffset = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_READONLY);
    label_10 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("Version : "), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editInfoVersion = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_READONLY);
    label_11 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("Size : "), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editInfoSize = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_READONLY);
    label_12 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("Flag : "), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editInfoFlag = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_READONLY);
    label_13 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("Index : "), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editInfoIndex = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_READONLY);
    label_14 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("CompSize : "), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editInfoCompSize = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_READONLY);
    m_btnInfoExport = new wxButton(m_ctrlPanel, IDB_DATA_EXPORT, wxT("Export ..."));
    panel_1 = new wxPanel(m_ctrlPanel, wxID_ANY);

	return 0;
}

int CNotebookInfoPanel::SetPanelControls()
{
    wxBoxSizer* sizer_5 = new wxBoxSizer(wxVERTICAL);
    wxStaticBoxSizer* sizer_6 = new wxStaticBoxSizer(sizer_6_staticbox, wxHORIZONTAL);
    wxBoxSizer* sizer_7 = new wxBoxSizer(wxVERTICAL);
    wxBoxSizer* sizer_14 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer* sizer_13 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer* sizer_12 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer* sizer_11 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer* sizer_10 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer* sizer_9 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer* sizer_8 = new wxBoxSizer(wxHORIZONTAL);

    wxStaticBoxSizer* sizer_16 = new wxStaticBoxSizer(sizer_16_staticbox, wxHORIZONTAL);


    sizer_16->Add(m_labelFileName, 0, wxEXPAND|wxALIGN_CENTER_VERTICAL, 0);
    sizer_5->Add(sizer_16, 0, wxEXPAND, 0);

	sizer_8->Add(label_8, 2, wxLEFT|wxALIGN_CENTER_VERTICAL, 4);
    sizer_8->Add(m_editInfoFileName, 8, wxRIGHT, 16);
    sizer_7->Add(sizer_8, 0, wxBOTTOM|wxEXPAND, 4);
    sizer_9->Add(label_9, 2, wxLEFT|wxALIGN_CENTER_VERTICAL, 4);
    sizer_9->Add(m_editInfoOffset, 8, wxRIGHT, 16);
    sizer_7->Add(sizer_9, 0, wxBOTTOM|wxEXPAND, 4);
    sizer_10->Add(label_10, 2, wxLEFT|wxALIGN_CENTER_VERTICAL, 4);
    sizer_10->Add(m_editInfoVersion, 8, wxRIGHT, 16);
    sizer_7->Add(sizer_10, 0, wxBOTTOM|wxEXPAND, 4);
    sizer_11->Add(label_11, 2, wxLEFT|wxALIGN_CENTER_VERTICAL, 4);
    sizer_11->Add(m_editInfoSize, 8, wxRIGHT, 16);
    sizer_7->Add(sizer_11, 0, wxBOTTOM|wxEXPAND, 4);
    sizer_12->Add(label_12, 2, wxLEFT|wxALIGN_CENTER_VERTICAL, 4);
    sizer_12->Add(m_editInfoFlag, 8, wxRIGHT, 16);
    sizer_7->Add(sizer_12, 0, wxBOTTOM|wxEXPAND, 4);
    sizer_13->Add(label_13, 2, wxLEFT|wxALIGN_CENTER_VERTICAL, 4);
    sizer_13->Add(m_editInfoIndex, 8, wxRIGHT, 16);
    sizer_7->Add(sizer_13, 0, wxBOTTOM|wxEXPAND, 4);
    sizer_14->Add(label_14, 2, wxLEFT|wxALIGN_CENTER_VERTICAL, 4);
    sizer_14->Add(m_editInfoCompSize, 8, wxRIGHT, 16);
    sizer_7->Add(sizer_14, 0, wxBOTTOM|wxEXPAND, 4);
    sizer_6->Add(sizer_7, 1, wxEXPAND, 0);
    sizer_5->Add(sizer_6, 0, wxEXPAND, 0);
    sizer_5->Add(m_btnInfoExport, 0, wxTOP|wxBOTTOM|wxEXPAND, 4);
    sizer_5->Add(panel_1, 1, wxEXPAND, 0);
    m_ctrlPanel->SetSizer(sizer_5);

	m_ctrlPanel->Layout();

	return 0;
}

void CNotebookInfoPanel::DisplayInfo(const MPQData::TFileData *data)
{
	if(data == NULL)
	{
		m_btnInfoExport->Disable();
	}
	else
	{
		m_labelFileName->SetLabel(Toolkit::String2wxString(data->m_strName));
		m_editInfoFileName->SetValue(Toolkit::String2wxString(data->m_strName));
		wxString str;
		str.sprintf(wxT("0x%X"), data->m_pPointer);
		m_editInfoOffset->SetValue(str);
		str.sprintf(wxT("0x%X"), data->m_uiVersion); 
		m_editInfoVersion->SetValue(str);
		str.sprintf(wxT("%d Bytes"), data->m_uiSize);
		m_editInfoSize->SetValue(str);
		str.sprintf(wxT("0x%X"), data->m_uiFlag);
		m_editInfoFlag->SetValue(str);
		str.sprintf(wxT("0x%X"), data->m_uiIndex);
		m_editInfoIndex->SetValue(str);
		str.sprintf(wxT("%d Bytes"), data->m_uiCompSize);
		m_editInfoCompSize->SetValue(str);

		m_btnInfoExport->Enable();
	}
}

////

CNotebookDataPanel::CNotebookDataPanel()
: CNotebookPanel(PT_DATA, wxT("Data Dump"), 0)
{
}

CNotebookDataPanel::~CNotebookDataPanel()
{
}

int CNotebookDataPanel::CreatePanelControls()
{
	sizer_15_staticbox = new wxStaticBox(m_ctrlPanel, -1, wxEmptyString);
    m_labelDataFileName = new wxStaticText(m_ctrlPanel, wxID_ANY, wxEmptyString);
    m_ctrlDataText = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_MULTILINE|wxTE_READONLY|wxHSCROLL);

	return 0;
}

int CNotebookDataPanel::SetPanelControls()
{
    wxBoxSizer* sizer_4 = new wxBoxSizer(wxVERTICAL);
    wxStaticBoxSizer* sizer_15 = new wxStaticBoxSizer(sizer_15_staticbox, wxHORIZONTAL);
 
	sizer_15->Add(m_labelDataFileName, 0, wxEXPAND|wxALIGN_RIGHT|wxALIGN_CENTER_VERTICAL, 0);
    sizer_4->Add(sizer_15, 0, wxBOTTOM|wxEXPAND, 4);
    sizer_4->Add(m_ctrlDataText, 1, wxEXPAND, 0);
    m_ctrlPanel->SetSizer(sizer_4);

	m_labelDataFileName->SetLabel(wxT(""));
    m_ctrlDataText->SetFont(wxFont(10, wxMODERN, wxNORMAL, wxNORMAL, 0, wxT("Courier New")));

	m_ctrlPanel->Layout();

	return 0;
}

bool CNotebookDataPanel::CheckDataFileName(const wxString& file) const
{
	return file == m_labelDataFileName->GetLabel();
}

void CNotebookDataPanel::SetDataFileName(const wxString& str)
{
	m_labelDataFileName->SetLabel(str);
}

void CNotebookDataPanel::Refresh(const wxString& str)
{
	m_labelDataFileName->SetLabel(str);
	m_ctrlDataText->Clear();
}

void CNotebookDataPanel::AppendEnd()
{
	m_ctrlDataText->ShowPosition(0);
}

void CNotebookDataPanel::AppendData(const wxString& str)
{
	m_ctrlDataText->AppendText(str);
}

////

CNotebookDBCPanel::CNotebookDBCPanel()
: CNotebookPanel(PT_DBC, wxT("DBC"), 0)
{
}

CNotebookDBCPanel::~CNotebookDBCPanel()
{
}

int CNotebookDBCPanel::CreatePanelControls()
{
    sizer_6_staticbox = new wxStaticBox(m_ctrlPanel, -1, wxEmptyString);
    sizer_3_staticbox = new wxStaticBox(m_ctrlPanel, -1, wxEmptyString);
    m_labelFileName = new wxStaticText(m_ctrlPanel, wxID_ANY, wxEmptyString);
    label_6 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("Signature:"), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editSignature = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_READONLY);
    label_8 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("Records:"), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editRecords = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_READONLY);
    label_9 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("Fields:"), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editFields = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_READONLY);
    label_7 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("Record Size:"), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editRecordSize = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_READONLY);
    label_10 = new wxStaticText(m_ctrlPanel, wxID_ANY, wxT("String Size:"), wxDefaultPosition, wxDefaultSize, wxALIGN_RIGHT);
    m_editStringSize = new wxTextCtrl(m_ctrlPanel, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_READONLY);
    panel_2 = new wxPanel(m_ctrlPanel, wxID_ANY);
    panel_3 = new wxPanel(m_ctrlPanel, wxID_ANY);
    m_ctrlGrid = new wxGrid(m_ctrlPanel, wxID_ANY);

	return 0;
}

int CNotebookDBCPanel::SetPanelControls()
{
	wxBoxSizer* sizer_2 = new wxBoxSizer(wxVERTICAL);
    wxStaticBoxSizer* sizer_6 = new wxStaticBoxSizer(sizer_6_staticbox, wxVERTICAL);
    wxBoxSizer* sizer_8 = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer* sizer_7 = new wxBoxSizer(wxHORIZONTAL);
    wxStaticBoxSizer* sizer_3 = new wxStaticBoxSizer(sizer_3_staticbox, wxHORIZONTAL);
    sizer_3->Add(m_labelFileName, 0, wxEXPAND|wxALIGN_CENTER_VERTICAL, 0);
    sizer_2->Add(sizer_3, 0, wxEXPAND, 0);
    sizer_7->Add(label_6, 4, wxALIGN_CENTER_VERTICAL, 0);
    sizer_7->Add(m_editSignature, 5, wxEXPAND, 0);
    sizer_7->Add(label_8, 4, wxALIGN_CENTER_VERTICAL, 0);
    sizer_7->Add(m_editRecords, 5, wxEXPAND, 0);
    sizer_7->Add(label_9, 4, wxALIGN_CENTER_VERTICAL, 0);
    sizer_7->Add(m_editFields, 5, wxEXPAND, 0);
    sizer_6->Add(sizer_7, 0, wxTOP|wxBOTTOM|wxEXPAND, 2);
    sizer_8->Add(label_7, 4, wxALIGN_CENTER_VERTICAL, 0);
    sizer_8->Add(m_editRecordSize, 5, wxEXPAND, 0);
    sizer_8->Add(label_10, 4, wxALIGN_CENTER_VERTICAL, 0);
    sizer_8->Add(m_editStringSize, 5, wxEXPAND, 0);
    sizer_8->Add(panel_2, 4, wxEXPAND, 0);
    sizer_8->Add(panel_3, 5, wxEXPAND, 0);
    sizer_6->Add(sizer_8, 0, wxEXPAND, 2);
    sizer_2->Add(sizer_6, 0, wxBOTTOM|wxEXPAND, 4);
    sizer_2->Add(m_ctrlGrid, 1, wxEXPAND, 0);
    m_ctrlPanel->SetSizer(sizer_2);

    m_ctrlGrid->CreateGrid(0, 0,wxGrid::wxGridSelectRows);
    m_ctrlGrid->EnableEditing(false);
    m_ctrlGrid->SetGridLineColour(wxColour(0, 0, 255));
//    m_ctrlGrid->SetColLabelValue(0, wxEmptyString);

	m_ctrlPanel->Layout();

	return 0;
}

void CNotebookDBCPanel::SetFileName(const wxString &str)
{
	m_labelFileName->SetLabel(str);
}

void CNotebookDBCPanel::SetHeaderInfo(const MPQData::CDBCHeader &header)
{
	wxString str;
	str.sprintf(wxT("%c%c%c%c"), header.m_acSignature[0], header.m_acSignature[1], header.m_acSignature[2], header.m_acSignature[3]);
	m_editSignature->SetValue(str);
	str.sprintf(wxT("%d"), header.m_iRecords);
	m_editRecords->SetValue(str);
	str.sprintf(wxT("%d"), header.m_iFields);
	m_editFields->SetValue(str);
	str.sprintf(wxT("%d"), header.m_iRecordSize);
	m_editRecordSize->SetValue(str);
	str.sprintf(wxT("%d"), header.m_iBlockSize);
	m_editStringSize->SetValue(str);
}

void CNotebookDBCPanel::InitGrid(int fields, const CMPQDBCFieldManager::TFieldMap* mapField)
{
	m_ctrlGrid->ClearGrid();
	if(m_ctrlGrid->GetNumberCols() > 0)
		m_ctrlGrid->DeleteCols(0, m_ctrlGrid->GetNumberCols());
	if(m_ctrlGrid->GetNumberRows() > 0)
		m_ctrlGrid->DeleteRows(0, m_ctrlGrid->GetNumberRows());
	m_ctrlGrid->AppendCols(fields);
	if(mapField != NULL)
	{
		for(CMPQDBCFieldManager::TFieldMap::const_iterator it = mapField->begin(); it != mapField->end(); ++ it)
		{
			if(it->first < fields)
			{
				m_ctrlGrid->SetColLabelValue(it->first, Toolkit::String2wxString(it->second->m_strTitle));
			}
		}
	}
}

void CNotebookDBCPanel::AppendRow()
{
	m_ctrlGrid->AppendRows(1);
}

void CNotebookDBCPanel::SetGridData(int row, int col, const wxString& data)
{
	m_ctrlGrid->SetCellValue(row, col, data);
}
////

BEGIN_EVENT_TABLE(CNotebookBLPPanel::CScrolledBitmapCanvas, wxScrolledWindow)
    EVT_PAINT(CNotebookBLPPanel::CScrolledBitmapCanvas::OnPaint)
END_EVENT_TABLE()

CNotebookBLPPanel::CScrolledBitmapCanvas::CScrolledBitmapCanvas(wxWindow *parent, wxWindowID id, const wxPoint &pos, const wxSize &size)
: wxScrolledWindow(parent, id, pos, size)
{
}

CNotebookBLPPanel::CScrolledBitmapCanvas::~CScrolledBitmapCanvas()
{
}

int CNotebookBLPPanel::CScrolledBitmapCanvas::InitPNGHandler()
{
	//wxPNGHandler handler;
	//wxImage image;
	//image.AddHandler(&handler);
	return 0;
}

void CNotebookBLPPanel::CScrolledBitmapCanvas::OnPaint(wxPaintEvent &event)
{
	if(_bitmapPNG.Ok())
	{
		wxPaintDC dc(this);
		PrepareDC(dc);

		dc.DrawBitmap(_bitmapPNG, 0, 0);
	}
	event.Skip();
}

int CNotebookBLPPanel::CScrolledBitmapCanvas::SetBitmap(const wxString& file, wxSize& size)
{
	if(!_bitmapPNG.LoadFile(file, wxBITMAP_TYPE_PNG))
		return -1;
	size.Set(_bitmapPNG.GetWidth(), _bitmapPNG.GetHeight());
	return 0;
}

CNotebookBLPPanel::CNotebookBLPPanel()
: CNotebookPanel(PT_BLP, wxT("BLP"), 0)
{
}

CNotebookBLPPanel::~CNotebookBLPPanel()
{
}

int CNotebookBLPPanel::CreatePanelControls()
{
    sizer_3_staticbox = new wxStaticBox(m_ctrlPanel, -1, wxEmptyString);
    m_labelFileName = new wxStaticText(m_ctrlPanel, wxID_ANY, wxEmptyString);
    m_canvasBitmap = new CScrolledBitmapCanvas(m_ctrlPanel, IDC_NOTEBOOK_BLP_BITMAPCANVAS, wxPoint(0, 0), wxSize(-1, -1));
	m_canvasBitmap->InitPNGHandler();

	return 0;
}

int CNotebookBLPPanel::SetPanelControls()
{
	wxBoxSizer* sizer_1 = new wxBoxSizer(wxVERTICAL);
    wxBoxSizer* sizer_2 = new wxBoxSizer(wxVERTICAL);
    wxStaticBoxSizer* sizer_3 = new wxStaticBoxSizer(sizer_3_staticbox, wxHORIZONTAL);
    sizer_3->Add(m_labelFileName, 0, wxEXPAND|wxALIGN_CENTER_VERTICAL, 0);
	sizer_2->Add(sizer_3, 0, wxBOTTOM|wxEXPAND, 4);
    sizer_2->Add(m_canvasBitmap, 1, wxEXPAND, 0);
    m_ctrlPanel->SetSizer(sizer_2);

	m_ctrlPanel->Layout();

	return 0;
}

void CNotebookBLPPanel::SetFileName(const wxString &str)
{
	m_labelFileName->SetLabel(str);
}

int CNotebookBLPPanel::ShowImage(const wxString& file)
{
	wxSize size(0, 0);
	if(m_canvasBitmap->SetBitmap(file, size) != 0)
		return -1;

	m_canvasBitmap->SetScrollbars(1, 1, size.GetWidth(), size.GetHeight());

	return 0;
}

